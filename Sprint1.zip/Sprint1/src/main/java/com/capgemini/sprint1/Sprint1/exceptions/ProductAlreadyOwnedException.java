package com.capgemini.sprint1.Sprint1.exceptions;

public class ProductAlreadyOwnedException extends Exception {
	private static final long serialVersionUID = 1L;

	public ProductAlreadyOwnedException() {
		super();
	}

}
