package com.capgemini.sprint1.Sprint1.exceptions;

public class EngineerNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public EngineerNotFoundException() {
		
	}

}
