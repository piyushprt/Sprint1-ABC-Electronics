package com.capgemini.sprint1.Sprint1.exceptions;

public class ProductOutOfWarrentyException extends Exception {
	private static final long serialVersionUID = 1L;

	public ProductOutOfWarrentyException() {
		super();
	}

}
