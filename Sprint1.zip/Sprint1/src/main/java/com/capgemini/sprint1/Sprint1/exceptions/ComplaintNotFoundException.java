package com.capgemini.sprint1.Sprint1.exceptions;

public class ComplaintNotFoundException extends Exception{
	private static final long serialVersionUID = 1L;

	public ComplaintNotFoundException() {
		super();
	}

}
